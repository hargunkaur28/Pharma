"""
shared/middleware/rbac.py
Role-Based Access Control middleware.
Validates JWT, extracts role, enforces permissions per route.
"""
from fastapi import Request, HTTPException, status, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import jwt, JWTError
from typing import List, Optional
from shared.config import get_settings

settings = get_settings()
security = HTTPBearer()

# Role hierarchy — what each role is allowed to do
ROLE_PERMISSIONS = {
    "head_office_admin": [
        "inventory:read", "inventory:write",
        "sales:read", "sales:write",
        "users:read", "users:write",
        "reports:read", "reports:export",
        "ai:read", "ai:query",
        "audit:read",
    ],
    "branch_pharmacist": [
        "inventory:read",
        "sales:read", "sales:write",
        "reports:read",
        "ai:query",
    ],
    "inventory_controller": [
        "inventory:read", "inventory:write",
        "sales:read",
        "reports:read",
        "ai:read", "ai:query",
    ],
    "customer_service_agent": [
        "sales:read",
        "reports:read",
    ],
    "system_auditor": [
        "audit:read",
        "reports:read",
    ],
}


class TokenPayload:
    def __init__(self, user_id: str, role: str, branch_id: Optional[str], permissions: List[str]):
        self.user_id = user_id
        self.role = role
        self.branch_id = branch_id
        self.permissions = permissions


def decode_token(token: str) -> TokenPayload:
    """Decode and validate JWT. Raises HTTPException on failure."""
    try:
        payload = jwt.decode(
            token,
            settings.JWT_PUBLIC_KEY,
            algorithms=[settings.JWT_ALGORITHM],
        )
        return TokenPayload(
            user_id=payload["sub"],
            role=payload["role"],
            branch_id=payload.get("branch_id"),
            permissions=payload.get("permissions", []),
        )
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )


def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> TokenPayload:
    """FastAPI dependency — extracts current user from Bearer token."""
    return decode_token(credentials.credentials)


def require_permissions(*required: str):
    """
    FastAPI dependency factory — checks user has ALL required permissions.

    Usage:
        @router.get("/stock", dependencies=[Depends(require_permissions("inventory:read"))])
    """
    def _check(user: TokenPayload = Depends(get_current_user)) -> TokenPayload:
        missing = [p for p in required if p not in user.permissions]
        if missing:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Missing permissions: {', '.join(missing)}",
            )
        return user
    return _check


def require_same_branch(user: TokenPayload, branch_id: str) -> None:
    """
    Enforce that branch-level staff can only access their own branch data.
    Head office admins and inventory controllers bypass this check.
    """
    bypass_roles = {"head_office_admin", "inventory_controller", "system_auditor"}
    if user.role not in bypass_roles:
        if user.branch_id != branch_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied: you can only view your assigned branch data",
            )
