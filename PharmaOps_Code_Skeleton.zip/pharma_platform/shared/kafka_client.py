"""
shared/kafka_client.py
Async Kafka producer/consumer utilities used across all services.
All domain events are published here for async inter-service communication.
"""
import json
import structlog
from aiokafka import AIOKafkaProducer, AIOKafkaConsumer
from shared.config import get_settings

log = structlog.get_logger()
settings = get_settings()

# ── Topic names ────────────────────────────────────────────────────────────────
TOPIC_STOCK_UPDATED = "stock.updated"
TOPIC_SALE_COMPLETED = "sale.completed"
TOPIC_REPLENISHMENT_REQUESTED = "replenishment.requested"
TOPIC_REPLENISHMENT_APPROVED = "replenishment.approved"
TOPIC_EXPIRY_ALERT = "stock.expiry_alert"
TOPIC_ANOMALY_DETECTED = "ai.anomaly_detected"
TOPIC_ERP_PO_REQUESTED = "erp.po_requested"
TOPIC_ERP_GRN_RECEIVED = "erp.grn_received"
TOPIC_AUDIT_EVENT = "audit.event"


_producer: AIOKafkaProducer = None


async def get_producer() -> AIOKafkaProducer:
    global _producer
    if _producer is None:
        _producer = AIOKafkaProducer(
            bootstrap_servers=settings.KAFKA_BOOTSTRAP_SERVERS,
            value_serializer=lambda v: json.dumps(v).encode("utf-8"),
        )
        await _producer.start()
    return _producer


async def publish_event(topic: str, event: dict, key: str = None) -> None:
    """Publish a domain event to a Kafka topic."""
    producer = await get_producer()
    try:
        key_bytes = key.encode("utf-8") if key else None
        await producer.send_and_wait(topic, value=event, key=key_bytes)
        log.info("kafka_event_published", topic=topic, key=key)
    except Exception as e:
        log.error("kafka_publish_failed", topic=topic, error=str(e))
        raise


async def consume_events(topics: list, group_id: str, handler):
    """
    Generic Kafka consumer. Runs indefinitely, calling handler(msg) per message.
    Used by notification service, audit service, etc.
    """
    consumer = AIOKafkaConsumer(
        *topics,
        bootstrap_servers=settings.KAFKA_BOOTSTRAP_SERVERS,
        group_id=group_id,
        auto_offset_reset="earliest",
        value_deserializer=lambda v: json.loads(v.decode("utf-8")),
    )
    await consumer.start()
    try:
        async for msg in consumer:
            log.info("kafka_event_received", topic=msg.topic, offset=msg.offset)
            await handler(msg.value)
    finally:
        await consumer.stop()
