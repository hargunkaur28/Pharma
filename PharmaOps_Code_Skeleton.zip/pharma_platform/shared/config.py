"""
shared/config.py
Common configuration loaded from environment variables across all services.
"""
from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # Database
    DATABASE_URL: str = "postgresql+asyncpg://pharma:secret@localhost:5432/pharmadb"

    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"

    # Kafka
    KAFKA_BOOTSTRAP_SERVERS: str = "localhost:9092"

    # JWT
    JWT_PRIVATE_KEY: str = ""        # RS256 private key (loaded from Vault in prod)
    JWT_PUBLIC_KEY: str = ""         # RS256 public key
    JWT_ALGORITHM: str = "RS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 15
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # Encryption
    AES_ENCRYPTION_KEY: str = ""     # AES-256 key for PII fields (from Vault)

    # Services (internal URLs)
    AUTH_SERVICE_URL: str = "http://auth-service:8001"
    INVENTORY_SERVICE_URL: str = "http://inventory-service:8002"
    SALES_SERVICE_URL: str = "http://sales-service:8003"
    AI_SERVICE_URL: str = "http://ai-service:8005"

    # Environment
    ENVIRONMENT: str = "development"  # development | staging | production

    class Config:
        env_file = ".env"
        case_sensitive = True


@lru_cache()
def get_settings() -> Settings:
    return Settings()
