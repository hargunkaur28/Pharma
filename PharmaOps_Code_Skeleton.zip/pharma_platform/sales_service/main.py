"""
sales_service/main.py
Sales Service — POS transactions, prescription dispensing, returns.
Every sale atomically deducts stock and writes an audit event.
"""
from fastapi import FastAPI, Depends, BackgroundTasks, HTTPException, status
from sqlalchemy import Column, String, Integer, Numeric, DateTime, ForeignKey, Enum as SAEnum
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
import uuid
import enum
import httpx
import structlog
from shared.middleware.rbac import get_current_user, require_permissions, TokenPayload
from shared.kafka_client import publish_event, TOPIC_SALE_COMPLETED, TOPIC_STOCK_UPDATED, TOPIC_AUDIT_EVENT
from shared.config import get_settings
from prometheus_fastapi_instrumentator import Instrumentator

log = structlog.get_logger()
settings = get_settings()

app = FastAPI(title="Sales Service", version="1.0.0")
Instrumentator().instrument(app).expose(app)


# ── Models ─────────────────────────────────────────────────────────────────────

class SaleType(str, enum.Enum):
    OTC = "otc"
    PRESCRIPTION = "prescription"
    RETURN = "return"


class SaleStatus(str, enum.Enum):
    COMPLETED = "completed"
    PENDING = "pending"
    VOIDED = "voided"


class Transaction(Base):
    __tablename__ = "transactions"
    transaction_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    branch_id = Column(String(20), nullable=False, index=True)
    pharmacist_id = Column(String(50), nullable=False)
    sale_type = Column(SAEnum(SaleType), nullable=False)
    payment_method = Column(String(30))
    total_amount = Column(Numeric(12, 2), nullable=False)
    status = Column(SAEnum(SaleStatus), default=SaleStatus.COMPLETED)
    prescription_ref = Column(String(100), nullable=True)    # For Rx sales
    created_at = Column(DateTime, server_default="now()", index=True)


class TransactionItem(Base):
    __tablename__ = "transaction_items"
    item_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    transaction_id = Column(UUID(as_uuid=True), ForeignKey("transactions.transaction_id"))
    product_id = Column(String(50), nullable=False)
    batch_id = Column(String(50), nullable=False)
    quantity = Column(Integer, nullable=False)
    unit_price = Column(Numeric(10, 2), nullable=False)
    line_total = Column(Numeric(12, 2), nullable=False)


# ── Schemas ────────────────────────────────────────────────────────────────────

class SaleItemIn(BaseModel):
    product_id: str
    batch_id: str
    quantity: int
    unit_price: float


class TransactionIn(BaseModel):
    branch_id: str
    sale_type: SaleType
    items: List[SaleItemIn]
    payment_method: str
    total_amount: float
    prescription_ref: Optional[str] = None


class TransactionOut(BaseModel):
    transaction_id: str
    receipt_url: str
    status: str
    created_at: datetime


# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.post(
    "/api/v1/sales/transaction",
    response_model=TransactionOut,
    status_code=201,
    dependencies=[Depends(require_permissions("sales:write"))],
)
async def create_transaction(
    body: TransactionIn,
    background_tasks: BackgroundTasks,
    user: TokenPayload = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Record a sale (OTC or Prescription).
    1. Validates stock availability via Inventory Service
    2. Creates Transaction + TransactionItem records (atomic)
    3. Publishes TOPIC_SALE_COMPLETED → Inventory Service deducts stock
    4. Publishes TOPIC_AUDIT_EVENT → Audit Service logs the change
    """
    # Step 1: Validate stock for each item (call Inventory Service)
    async with httpx.AsyncClient() as client:
        for item in body.items:
            resp = await client.get(
                f"{settings.INVENTORY_SERVICE_URL}/api/v1/inventory/stock",
                params={"branch_id": body.branch_id, "product_id": item.product_id},
                headers={"Authorization": f"Bearer {_get_internal_token()}"},
            )
            if resp.status_code != 200:
                raise HTTPException(status_code=400, detail=f"Could not verify stock for product {item.product_id}")
            stock = resp.json()
            if stock["quantity_available"] < item.quantity:
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail=f"Insufficient stock for {stock['product_name']}: available={stock['quantity_available']}, requested={item.quantity}",
                )
            # Block expired products
            if stock["status"] == "out_of_stock":
                raise HTTPException(status_code=400, detail=f"Product {stock['product_name']} is out of stock")

    # Step 2: Persist transaction
    txn = Transaction(
        branch_id=body.branch_id,
        pharmacist_id=user.user_id,
        sale_type=body.sale_type,
        payment_method=body.payment_method,
        total_amount=body.total_amount,
        prescription_ref=body.prescription_ref,
    )
    db.add(txn)
    for item in body.items:
        db.add(TransactionItem(
            transaction_id=txn.transaction_id,
            product_id=item.product_id,
            batch_id=item.batch_id,
            quantity=item.quantity,
            unit_price=item.unit_price,
            line_total=item.quantity * item.unit_price,
        ))
    await db.commit()

    # Step 3 & 4: Publish events asynchronously
    event_payload = {
        "transaction_id": str(txn.transaction_id),
        "branch_id": body.branch_id,
        "pharmacist_id": user.user_id,
        "sale_type": body.sale_type,
        "items": [i.dict() for i in body.items],
        "total_amount": body.total_amount,
        "timestamp": datetime.utcnow().isoformat(),
    }
    background_tasks.add_task(publish_event, TOPIC_SALE_COMPLETED, event_payload)
    background_tasks.add_task(publish_event, TOPIC_AUDIT_EVENT, {
        "event_type": "sale_completed",
        "actor": user.user_id,
        "entity_id": str(txn.transaction_id),
        "details": event_payload,
    })

    log.info("transaction_created", txn_id=str(txn.transaction_id), amount=body.total_amount)
    return TransactionOut(
        transaction_id=str(txn.transaction_id),
        receipt_url=f"/api/v1/sales/receipt/{txn.transaction_id}",
        status="completed",
        created_at=txn.created_at,
    )


def _get_internal_token() -> str:
    """Returns a service-to-service JWT for internal API calls (M2M auth)."""
    # In production: cached short-lived token from Auth Service
    return "internal-service-token"


@app.get("/health")
async def health():
    return {"status": "ok", "service": "sales"}
