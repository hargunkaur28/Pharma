"""
inventory_service/main.py
Inventory Management Service — stock levels, batches, expiry tracking, replenishment.
"""
from fastapi import FastAPI, Depends, Query, BackgroundTasks
from sqlalchemy import Column, String, Integer, DateTime, Numeric, ForeignKey, Enum
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.sql import func
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, date, timedelta
import uuid
import enum
import structlog
from shared.middleware.rbac import get_current_user, require_permissions, require_same_branch, TokenPayload
from shared.kafka_client import publish_event, TOPIC_STOCK_UPDATED, TOPIC_REPLENISHMENT_REQUESTED, TOPIC_EXPIRY_ALERT
from prometheus_fastapi_instrumentator import Instrumentator

log = structlog.get_logger()

app = FastAPI(title="Inventory Service", version="1.0.0")
Instrumentator().instrument(app).expose(app)


# ── SQLAlchemy Models ──────────────────────────────────────────────────────────

class StockStatus(str, enum.Enum):
    OK = "ok"
    LOW = "low"
    CRITICAL = "critical"
    OUT_OF_STOCK = "out_of_stock"


class Product(Base):
    __tablename__ = "products"
    product_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    sku = Column(String(50), unique=True, nullable=False, index=True)
    category = Column(String(100))
    requires_prescription = Column(String(5), default="no")   # yes/no
    reorder_point = Column(Integer, default=100)
    unit_price = Column(Numeric(10, 2))
    is_active = Column(String(5), default="yes")


class Batch(Base):
    __tablename__ = "batches"
    batch_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    product_id = Column(UUID(as_uuid=True), ForeignKey("products.product_id"))
    location_id = Column(String(20), nullable=False, index=True)   # branch_id or "WAREHOUSE"
    batch_no = Column(String(100), nullable=False)
    quantity = Column(Integer, nullable=False, default=0)
    expiry_date = Column(DateTime, nullable=False, index=True)
    mfg_date = Column(DateTime, nullable=True)
    created_at = Column(DateTime, server_default=func.now())


class StockMovement(Base):
    """Immutable audit trail of every stock change."""
    __tablename__ = "stock_movements"
    movement_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    product_id = Column(UUID(as_uuid=True), ForeignKey("products.product_id"))
    batch_id = Column(UUID(as_uuid=True), ForeignKey("batches.batch_id"))
    from_location = Column(String(20), nullable=True)
    to_location = Column(String(20), nullable=True)
    quantity = Column(Integer, nullable=False)
    reason = Column(String(255))          # "sale", "replenishment", "transfer", "adjustment"
    user_id = Column(String(50), nullable=False)
    timestamp = Column(DateTime, server_default=func.now(), index=True)


class ReplenishmentRequest(Base):
    __tablename__ = "replenishment_requests"
    req_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    branch_id = Column(String(20), nullable=False)
    product_id = Column(UUID(as_uuid=True), ForeignKey("products.product_id"))
    requested_qty = Column(Integer, nullable=False)
    reason = Column(String(500))
    status = Column(String(30), default="pending_approval")   # pending/approved/rejected/fulfilled
    requested_by = Column(String(50), nullable=False)
    approved_by = Column(String(50), nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, onupdate=func.now())


# ── Pydantic Schemas ───────────────────────────────────────────────────────────

class BatchOut(BaseModel):
    batch_id: str
    batch_no: str
    expiry_date: datetime
    quantity: int

    class Config:
        from_attributes = True


class StockResponse(BaseModel):
    product_id: str
    product_name: str
    sku: str
    branch_id: str
    quantity_available: int
    reorder_point: int
    status: str
    batches: List[BatchOut]


class ReplenishmentRequestIn(BaseModel):
    branch_id: str
    product_id: str
    requested_qty: int
    reason: Optional[str] = None


class ReplenishmentRequestOut(BaseModel):
    request_id: str
    status: str
    created_at: datetime


# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.get(
    "/api/v1/inventory/stock",
    response_model=StockResponse,
    dependencies=[Depends(require_permissions("inventory:read"))],
)
async def get_stock(
    branch_id: str,
    product_id: str,
    user: TokenPayload = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Get stock level + batch breakdown for a product at a branch.
    Branch-level staff can only query their assigned branch (enforced by RLS + RBAC).
    """
    require_same_branch(user, branch_id)

    # Fetch active batches ordered FEFO (First Expired, First Out)
    result = await db.execute(
        select(Batch)
        .where(Batch.product_id == product_id, Batch.location_id == branch_id)
        .where(Batch.expiry_date > datetime.utcnow())   # exclude expired
        .order_by(Batch.expiry_date.asc())
    )
    batches = result.scalars().all()
    total_qty = sum(b.quantity for b in batches)

    product = await db.get(Product, product_id)
    if not product:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Product not found")

    status_str = "ok"
    if total_qty == 0:
        status_str = "out_of_stock"
    elif total_qty < product.reorder_point * 0.25:
        status_str = "critical"
    elif total_qty < product.reorder_point:
        status_str = "low"

    return StockResponse(
        product_id=str(product.product_id),
        product_name=product.name,
        sku=product.sku,
        branch_id=branch_id,
        quantity_available=total_qty,
        reorder_point=product.reorder_point,
        status=status_str,
        batches=[BatchOut.from_orm(b) for b in batches],
    )


@app.post(
    "/api/v1/inventory/replenishment-request",
    response_model=ReplenishmentRequestOut,
    status_code=201,
    dependencies=[Depends(require_permissions("inventory:read"))],
)
async def create_replenishment_request(
    body: ReplenishmentRequestIn,
    background_tasks: BackgroundTasks,
    user: TokenPayload = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Submit a replenishment request for a branch.
    Publishes Kafka event → Inventory Controller notified → ERP PO on approval.
    """
    require_same_branch(user, body.branch_id)

    req = ReplenishmentRequest(
        branch_id=body.branch_id,
        product_id=body.product_id,
        requested_qty=body.requested_qty,
        reason=body.reason,
        requested_by=user.user_id,
    )
    db.add(req)
    await db.commit()
    await db.refresh(req)

    background_tasks.add_task(
        publish_event,
        TOPIC_REPLENISHMENT_REQUESTED,
        {
            "request_id": str(req.req_id),
            "branch_id": body.branch_id,
            "product_id": body.product_id,
            "requested_qty": body.requested_qty,
            "requested_by": user.user_id,
        },
    )

    log.info("replenishment_request_created", request_id=str(req.req_id))
    return ReplenishmentRequestOut(
        request_id=str(req.req_id),
        status=req.status,
        created_at=req.created_at,
    )


@app.get("/api/v1/inventory/expiry-alerts")
async def get_expiry_alerts(
    days_ahead: int = Query(30, ge=1, le=365),
    branch_id: Optional[str] = None,
    user: TokenPayload = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Returns batches expiring within `days_ahead` days.
    Used by daily cron + dashboard alerts.
    """
    cutoff = datetime.utcnow() + timedelta(days=days_ahead)
    query = select(Batch).where(
        Batch.expiry_date <= cutoff,
        Batch.expiry_date > datetime.utcnow(),
        Batch.quantity > 0,
    )
    if branch_id:
        require_same_branch(user, branch_id)
        query = query.where(Batch.location_id == branch_id)
    result = await db.execute(query.order_by(Batch.expiry_date.asc()))
    batches = result.scalars().all()
    return {"count": len(batches), "batches": [BatchOut.from_orm(b) for b in batches]}


@app.get("/health")
async def health():
    return {"status": "ok", "service": "inventory"}
