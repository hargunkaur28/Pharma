# Omnichannel Pharmacy Operations Platform (OPOP)
## Python/FastAPI Microservices — Code Skeleton

### Project Structure
```
pharma_platform/
├── api_gateway/          # Kong/FastAPI gateway — routing, auth enforcement
├── auth_service/         # JWT auth, RBAC, user management
├── inventory_service/    # Stock, batches, expiry, replenishment
├── sales_service/        # POS, prescriptions, returns
├── ai_service/           # Forecasting, anomaly detection, chat query
├── shared/               # Common models, middleware, kafka utils
├── docker-compose.yml    # Local dev orchestration
└── requirements.txt      # Python dependencies
```

### Run locally
```bash
docker-compose up --build
```
Services available at:
- API Gateway:   http://localhost:8080
- Auth Service:  http://localhost:8001/docs
- Inventory:     http://localhost:8002/docs
- Sales:         http://localhost:8003/docs
- AI Service:    http://localhost:8005/docs
