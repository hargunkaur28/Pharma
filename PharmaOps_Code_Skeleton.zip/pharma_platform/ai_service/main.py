"""
ai_service/main.py
AI/ML Service — demand forecasting, anomaly detection, conversational query.
All AI outputs are advisory. No autonomous system actions are triggered from here.
"""
from fastapi import FastAPI, Depends, Query, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
from prophet import Prophet
from sklearn.ensemble import IsolationForest
import structlog
from shared.middleware.rbac import get_current_user, require_permissions, require_same_branch, TokenPayload
from prometheus_fastapi_instrumentator import Instrumentator

log = structlog.get_logger()

app = FastAPI(title="AI Service", version="1.0.0")
Instrumentator().instrument(app).expose(app)


# ── Schemas ────────────────────────────────────────────────────────────────────

class ForecastResponse(BaseModel):
    product_id: str
    branch_id: str
    forecast_period_days: int
    predicted_demand: int
    confidence_interval: dict
    current_stock: int
    stock_sufficient: bool
    recommended_order_qty: int
    model_version: str
    generated_at: datetime


class AnomalyAlert(BaseModel):
    alert_id: str
    product_id: str
    branch_id: str
    severity: str              # low / medium / high / critical
    description: str
    detected_at: datetime
    metric_value: float
    expected_range: dict


class ChatRequest(BaseModel):
    question: str
    context: Optional[dict] = None    # branch_id, date range, etc.


class ChatResponse(BaseModel):
    answer: str
    generated_sql: Optional[str]      # Logged for audit (SELECT only)
    confidence: float                 # 0.0 - 1.0
    data: Optional[list] = None       # Tabular result if applicable
    warning: Optional[str] = None     # Low confidence / PII masking notice


# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.get(
    "/api/v1/ai/forecast",
    response_model=ForecastResponse,
    dependencies=[Depends(require_permissions("ai:read"))],
)
async def get_demand_forecast(
    product_id: str,
    branch_id: str,
    days: int = Query(30, ge=7, le=90),
    user: TokenPayload = Depends(get_current_user),
):
    """
    Predict demand for a product at a branch for the next N days.
    Uses Facebook Prophet for time-series forecasting.
    Model retrained nightly; served from cache during the day.

    GUARDRAIL: Output is advisory only. Replenishment requires human approval.
    """
    require_same_branch(user, branch_id)

    # In production: fetch historical sales from DB; here we simulate
    historical = _generate_synthetic_history(product_id, branch_id)

    model = Prophet(
        yearly_seasonality=True,
        weekly_seasonality=True,
        daily_seasonality=False,
        interval_width=0.95,
    )
    model.fit(historical)

    future = model.make_future_dataframe(periods=days)
    forecast = model.predict(future)
    future_forecast = forecast.tail(days)

    predicted = int(future_forecast["yhat"].clip(lower=0).sum())
    lower = int(future_forecast["yhat_lower"].clip(lower=0).sum())
    upper = int(future_forecast["yhat_upper"].clip(lower=0).sum())

    current_stock = _get_current_stock(product_id, branch_id)   # from cache/DB
    stock_sufficient = current_stock >= predicted
    recommended_order = max(0, predicted - current_stock + int(predicted * 0.1))  # 10% buffer

    log.info("forecast_generated", product=product_id, branch=branch_id, predicted=predicted)

    return ForecastResponse(
        product_id=product_id,
        branch_id=branch_id,
        forecast_period_days=days,
        predicted_demand=predicted,
        confidence_interval={"lower": lower, "upper": upper},
        current_stock=current_stock,
        stock_sufficient=stock_sufficient,
        recommended_order_qty=recommended_order,
        model_version="prophet-v2.1",
        generated_at=datetime.utcnow(),
    )


@app.get(
    "/api/v1/ai/anomalies",
    response_model=List[AnomalyAlert],
    dependencies=[Depends(require_permissions("ai:read"))],
)
async def get_anomalies(
    branch_id: Optional[str] = None,
    severity: Optional[str] = None,
    days_back: int = Query(7, ge=1, le=30),
    user: TokenPayload = Depends(get_current_user),
):
    """
    Returns anomalies detected by the Isolation Forest model.
    Detects: stock shrinkage, unusual return rates, demand spikes, POS discrepancies.
    Runs continuously; results cached and refreshed every 30 minutes.
    """
    if branch_id:
        require_same_branch(user, branch_id)

    # In production: load recent stock_movements from DB and run IsolationForest
    # Here we return a mock result to demonstrate structure
    alerts = _run_anomaly_detection(branch_id, days_back)
    if severity:
        alerts = [a for a in alerts if a.severity == severity]
    return alerts


@app.post(
    "/api/v1/ai/chat",
    response_model=ChatResponse,
    dependencies=[Depends(require_permissions("ai:query"))],
)
async def conversational_query(
    body: ChatRequest,
    user: TokenPayload = Depends(get_current_user),
):
    """
    Natural language query interface over operational data.
    Powered by LangChain + LLM (Claude/GPT-4 class).

    GUARDRAILS:
    - Only SELECT queries generated — no data modification
    - Query scope limited to user's authorised branches
    - PII masked in responses (names → initials, phone → last 4 digits)
    - All queries and generated SQL logged for audit
    - Low-confidence responses flagged with warning
    """
    # In production: LangChain SQL agent with read-only DB connection
    # and role-scoped schema access
    answer, sql, confidence, data = await _run_llm_query(
        question=body.question,
        user_role=user.role,
        branch_id=user.branch_id,
    )

    warning = None
    if confidence < 0.6:
        warning = "Low confidence response — please verify with a direct report."

    # Audit the query (async in production)
    log.info(
        "ai_chat_query",
        user_id=user.user_id,
        role=user.role,
        question=body.question[:100],
        generated_sql=sql,
        confidence=confidence,
    )

    return ChatResponse(
        answer=answer,
        generated_sql=sql,
        confidence=confidence,
        data=data,
        warning=warning,
    )


# ── Internal helpers ───────────────────────────────────────────────────────────

def _generate_synthetic_history(product_id: str, branch_id: str) -> pd.DataFrame:
    """
    In production: query sales_service DB for 2 years of daily sales data.
    Here we generate plausible synthetic data for demonstration.
    """
    dates = pd.date_range(end=datetime.utcnow(), periods=730, freq="D")
    np.random.seed(hash(product_id + branch_id) % 2**32)
    base = np.random.randint(10, 50)
    trend = np.linspace(0, 5, 730)
    seasonal = 5 * np.sin(np.arange(730) * 2 * np.pi / 7)   # weekly
    noise = np.random.normal(0, 3, 730)
    y = (base + trend + seasonal + noise).clip(min=0)
    return pd.DataFrame({"ds": dates, "y": y})


def _get_current_stock(product_id: str, branch_id: str) -> int:
    """In production: Redis cache → fallback to Inventory Service API."""
    return np.random.randint(50, 400)


def _run_anomaly_detection(branch_id: Optional[str], days_back: int) -> List[AnomalyAlert]:
    """
    Isolation Forest on stock movement features.
    In production: loads real data from DB.
    """
    return [
        AnomalyAlert(
            alert_id="ANM-001",
            product_id="PRD-IBU400",
            branch_id=branch_id or "BR-07",
            severity="high",
            description="Return rate 4× above 30-day baseline (18% vs 4.5% avg). Possible batch quality issue.",
            detected_at=datetime.utcnow() - timedelta(hours=6),
            metric_value=18.2,
            expected_range={"lower": 2.0, "upper": 7.0},
        ),
        AnomalyAlert(
            alert_id="ANM-002",
            product_id="PRD-MET500",
            branch_id=branch_id or "BR-07",
            severity="medium",
            description="Single-customer bulk purchase: 120 units in one transaction (+180% vs typical).",
            detected_at=datetime.utcnow() - timedelta(days=2),
            metric_value=120.0,
            expected_range={"lower": 1.0, "upper": 20.0},
        ),
    ]


async def _run_llm_query(question: str, user_role: str, branch_id: Optional[str]):
    """
    LangChain SQL agent pipeline:
    1. LLM generates SQL from natural language
    2. SQL validated (SELECT only, schema-scoped)
    3. Executed against read-only reporting replica
    4. Results formatted and PII masked
    """
    # Simplified mock — in production this calls LangChain SQL agent
    responses = {
        "paracetamol": (
            "Branch 7 (Sector 17) sold 1,240 units of Paracetamol last week, the highest across authorised branches.",
            "SELECT branch_id, SUM(quantity) as units FROM transaction_items ti JOIN transactions t ON ti.transaction_id=t.transaction_id WHERE ti.product_id='PCM-500' AND t.created_at >= NOW()-INTERVAL '7 days' GROUP BY branch_id ORDER BY units DESC",
            0.94,
            None,
        ),
    }
    question_lower = question.lower()
    for key, resp in responses.items():
        if key in question_lower:
            return resp
    return (
        f"I've analysed the operational data for your query. For a precise answer, I recommend generating a custom report from the Reports section. (Scope: {user_role}, branch: {branch_id})",
        None,
        0.55,
        None,
    )


@app.get("/health")
async def health():
    return {"status": "ok", "service": "ai"}
