"""
auth_service/main.py
Authentication & User Management Service — FastAPI application entry point.
Handles: Login, JWT issuance, refresh tokens, user CRUD, MFA for admins.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from prometheus_fastapi_instrumentator import Instrumentator
from auth_service.routers import auth_router, users_router
from auth_service.models.database import Base, engine

app = FastAPI(
    title="Auth Service",
    description="JWT authentication, RBAC user management for PharmaOps",
    version="1.0.0",
    docs_url="/docs",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # Tightened per environment in prod
    allow_methods=["*"],
    allow_headers=["*"],
)

# Prometheus metrics endpoint
Instrumentator().instrument(app).expose(app)

# Routers
app.include_router(auth_router, prefix="/api/v1/auth", tags=["Authentication"])
app.include_router(users_router, prefix="/api/v1/users", tags=["User Management"])


@app.on_event("startup")
async def startup():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


@app.get("/health")
async def health():
    return {"status": "ok", "service": "auth"}
