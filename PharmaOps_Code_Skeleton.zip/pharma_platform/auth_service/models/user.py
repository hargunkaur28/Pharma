"""
auth_service/models/user.py
SQLAlchemy ORM models for users, roles, and sessions.
Uses PostgreSQL Row-Level Security (RLS) for branch-level data isolation.
"""
from sqlalchemy import Column, String, Boolean, DateTime, Enum, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
import enum
from auth_service.models.database import Base


class UserRole(str, enum.Enum):
    HEAD_OFFICE_ADMIN = "head_office_admin"
    BRANCH_PHARMACIST = "branch_pharmacist"
    INVENTORY_CONTROLLER = "inventory_controller"
    CUSTOMER_SERVICE_AGENT = "customer_service_agent"
    SYSTEM_AUDITOR = "system_auditor"


class User(Base):
    __tablename__ = "users"

    user_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String(255), unique=True, nullable=False, index=True)
    hashed_password = Column(String(255), nullable=False)  # bcrypt, 12 rounds
    full_name = Column(String(255), nullable=False)
    role = Column(Enum(UserRole), nullable=False)
    branch_id = Column(String(20), nullable=True)          # null for HO/auditors
    is_active = Column(Boolean, default=True)
    mfa_secret = Column(String(64), nullable=True)         # TOTP secret (admins only)
    failed_login_attempts = Column(String(5), default="0")
    locked_until = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    sessions = relationship("RefreshToken", back_populates="user")


class RefreshToken(Base):
    """
    Refresh tokens stored in DB (also in Redis for fast lookup).
    Invalidating a token forces logout — supports forced logout by admin.
    """
    __tablename__ = "refresh_tokens"

    token_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.user_id"), nullable=False)
    token_hash = Column(String(255), nullable=False, unique=True)  # SHA-256 of token
    expires_at = Column(DateTime(timezone=True), nullable=False)
    revoked = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User", back_populates="sessions")
