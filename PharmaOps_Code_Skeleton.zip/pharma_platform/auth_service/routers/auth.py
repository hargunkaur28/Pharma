"""
auth_service/routers/auth.py
Login, token refresh, logout, MFA verification endpoints.
"""
from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel, EmailStr
from typing import Optional
from auth_service.models.database import get_db
from auth_service.services.auth_service import AuthService
from shared.kafka_client import publish_event, TOPIC_AUDIT_EVENT
import structlog

log = structlog.get_logger()
router = APIRouter()


# ── Request / Response schemas ─────────────────────────────────────────────────

class LoginRequest(BaseModel):
    username: EmailStr
    password: str
    mfa_code: Optional[str] = None   # Required for head_office_admin


class LoginResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "Bearer"
    expires_in: int = 900            # 15 minutes
    user: dict


class RefreshRequest(BaseModel):
    refresh_token: str


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.post("/login", response_model=LoginResponse)
async def login(
    body: LoginRequest,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
):
    """
    Authenticate user with email + password (+ optional MFA).
    Returns signed JWT (RS256) access token + refresh token.
    Locks account after 5 failed attempts for 15 minutes.
    """
    svc = AuthService(db)
    result = await svc.login(body.username, body.password, body.mfa_code)

    # Emit audit event asynchronously
    background_tasks.add_task(
        publish_event,
        TOPIC_AUDIT_EVENT,
        {
            "event_type": "user_login",
            "user_id": result["user"]["user_id"],
            "role": result["user"]["role"],
            "timestamp": result["user"].get("login_at"),
        },
    )
    return result


@router.post("/refresh")
async def refresh_token(body: RefreshRequest, db: AsyncSession = Depends(get_db)):
    """Issue a new access token using a valid refresh token."""
    svc = AuthService(db)
    return await svc.refresh(body.refresh_token)


@router.post("/logout")
async def logout(body: RefreshRequest, db: AsyncSession = Depends(get_db)):
    """Revoke refresh token — forces re-login on next access."""
    svc = AuthService(db)
    await svc.revoke_refresh_token(body.refresh_token)
    return {"message": "Logged out successfully"}


@router.post("/verify-mfa")
async def verify_mfa(user_id: str, code: str, db: AsyncSession = Depends(get_db)):
    """Validate TOTP MFA code for admin users."""
    svc = AuthService(db)
    valid = await svc.verify_totp(user_id, code)
    if not valid:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid MFA code")
    return {"valid": True}
